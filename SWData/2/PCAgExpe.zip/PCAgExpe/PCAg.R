##################################################
# This file contains the code for simulating the compression using PCA in a WSN.
##################################################

#Written by Yann-Aël Le Borgne
#October 2007



##################################################
#Generic functions


#Transform a dataframe in a matrix, as the function as.matrix does not work properly
tr<-function(data) {
 res<-NULL
 for (i in 1:ncol(data))
  res<-cbind(res,as.numeric(data[,i]))

 res
}

norm<-function(vec) {
 res<-sqrt(sum(vec^2))
 res
}

MSE<-function(vec) {
 sum(vec^2)/length(vec)
}

SSE<-function(vec) {
 sum(vec^2)
}

##################################################
#Get distance matrix from position pos
getDistMatFromPos<-function(
     pos         #A matrix of position of size p*2 where p is the number of sensors
     ) {
 p<-nrow(pos)
 distMat<-array(0,c(p,p))
 for (i in 1:p) {
  for (j in 1:p) {
   distMat[i,j]<-sqrt(sum((pos[i,]-pos[j,])^2))
  }
 }
 distMat
}

##################################################
#Sets to 0 entry of Ohm (the cov matrix) is corresponding sensors not in radiorange
#Crop is radio range
#distMat is distance matrix
cropMat<-function(Ohm,crop,distMat) {
 p<-ncol(distMat)
 for (i in 1:p) {
  for (j in 1:p) {
   if (distMat[i,j]>crop) Ohm[i,j]<-0
  }
 }
 Ohm
}

##################################################
#Get nb neighbors: number of entries different from zero
getNbNeigh<-function(vec) {
 sum(as.numeric(vec>0))
}


##################################################
#This orthonormalizes and normalize vec with respect to all columns of the matrix M
ortho<-function(M,vec) {
 n<-ncol(M)
 res<-vec
 for (i in 1:n) {
  res<-res-sum(M[,i]*res)*M[,i]/(norm(M[,i])^2)
 }
 #res<-res/norm(res)
 res
}

##################################################
#Compute the result of compression
#Radio range is in variable crop
#PC to retain is in q
#Training set is the 4th day, samples taken every 10minutes
#Test set are days from 5 to 8, samples taken every 30 seconds
compressionCropIntel<-function(
     X.tr.init,           #Training data, matrix of size p*N.tr
     X.ts.init,           #Test data, matrix of size p*N.ts
     crop,                #Radio range, can be a vector
     q,                   #Number of PC to retain, can be a vector
     distMat              #Distance matrix of sensors
     ) {
     	
 N.tr<-nrow(X.tr.init)
 N.ts<-nrow(X.ts.init)
 n<-ncol(X.tr.init)


 #'+2' as res also contains the results for a random basis and for a basis computed from the test data
 sizeres<-2+length(crop)
 res<-array(0,c(sizeres,length(q),N.ts))

 sens21<-array(0,c(length(q),N.ts))
 sens49<-array(0,c(length(q),N.ts))

 for (i in 1:(2+length(crop))) {

  X.tr<-X.tr.init
  X.ts<-X.ts.init


  meanx<-apply(X.tr,2,mean)
  meanx.ts<-apply(X.ts,2,mean)

  #Center data
  X.ts.mean<-scale(X.ts,meanx.ts,F)
  X.ts<-scale(X.ts,meanx,F)
  X.tr<-scale(X.tr,meanx,F)
  var.X.ts<-sum(as.numeric(X.ts)^2)/N.ts
  projReadings<-NULL

  #First round: Compute results for a random basis
  if (i==1) {
   X.tr<-X.ts
   matCov<-t(X.ts)%*%X.ts/nrow(X.ts)
  }
  #Second round: Compute results for the optimal basis using the test data for computing the covariance matrix
  if (i==2) {
   R.X<-array(rnorm(N.tr*52),c(N.tr,52))
   matCov<-cov(R.X)
  }
  #Remaining rounds: For each crop value specified in the call of the function
  if (i>2) {
   matCov<-t(X.tr)%*%X.tr/N.tr
   matCov<-cropMat(matCov,crop[i-2],distMat)
  }
  pcaRes<-eigen(matCov)

  for (k in 1:length(q)) {
   projReadings<-X.ts%*%pcaRes$vectors[,1:q[k]]%*%t(pcaRes$vectors[,1:q[k]])

   #Discrpency between these numbers as sensors 5 and 15 were removed
   sens21[k,]<-projReadings[,19]+meanx[19]
   sens49[k,]<-projReadings[,47]+meanx[47]

   error<-apply(projReadings-X.ts,1,SSE)/var.X.ts
   res[i,k,]<-error
  }
 }
 
 matCov<-t(X.tr)%*%X.tr/nrow(X.tr)
 pcaRes<-eigen(matCov)$val
 list(res,        #1 Matrix containing errors on the test set * it is sizecrop*q*length(X.ts)
      matCov,     #2 Covariance matrix of X.tr
      pcaRes,     #3 Eigendecomposition of matCov
      var.X.ts,   #4 Variance on test set
      sens21,     #5 Result of approximations for sensor 21 (19 col in data matrix)
      sens49)     #6 Result of approximations for sensor 49 (47 col in data matrix)
}


##################################################
#Compute the results for a ten CV
#Simply split the readings into train and test sets, and call the CompressionCropIntel function
comp10CV<-function(
       readings,  #The data. A matrix N*p
       crop,      #Radio range used to crop the covariance matrix
       q,         #Number of PCs to retain
       distMat    #Distance matrix of the sensors
       ) {
       	
 N<-nrow(readings)
 size.tr<-N/10
 size.crop<-length(crop)+2
 size.q<-length(q)

 resCV<-array(0,c(size.crop,size.q,10))

 for (i in 1:10) {
  I.tr<-((i-1)*size.tr):(i*size.tr)
  I.ts<-setdiff(1:N,I.tr)
  X.tr<-readings[I.tr,]
  X.ts<-readings[I.ts,]
  res<-compressionCropIntel(X.tr,X.ts,crop,q, distMat)
  for (j in 1:size.crop) {
   for (k in 1:size.q) {
    resCV[j,k,i]<-mean(res[[1]][j,k,])
   }
  }
 }
 resCV
}

