The data sets and R scripts provided in this archive allow to reproduce the experimental results obtained in 

Y. Le Borgne, J.M. Dricot, G. Bontempi. Principal Component Aggregation for Energy-efficient Information Extraction in Wireless Sensor Networks. Chapter accepted for publication in Knowledge Discovery from Sensor Data, Taylor and Francis/CRC Press, 2008.

R is a statistical software which can be freely downloaded from the CRAN website at http://cran.r-project.org/.

The data set is a subset of the data provided at http://db.csail.mit.edu/labdata/labdata.html.

To get the scripts running, first change the R working directory to the directory containing the files provided in this archive, and then load the file 'main.R'

source("main.R")

The different graphs can be obtained by executing the functions

drawTree()
drawProfile()
corGraph()
intelVarRet()
approx21()
IntelCommCost1()
IntelCommCost2()

Follow-up of this work can be found in 

Y. Le Borgne, S. Raybaud, and G. Bontempi. Distributed Principal Component Analysis for Wireless Sensor Networks. Sensors Journal, MDPI, Volume 8, Issue 8, August 2008, Pages 4821-4850. [Link to Sensors Journal - Open Access]

available for download at 

http://www.ulb.ac.be/di/map/yleborgn/research.html

and in my PhD thesis, available for download at 

http://www.ulb.ac.be/di/map/yleborgn
