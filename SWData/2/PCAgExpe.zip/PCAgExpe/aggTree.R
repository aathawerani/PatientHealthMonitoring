##################################################
# This file contains the code for simulating the creation of a routing tree, and for counting the nmber of packets receveid/transmitted for D, A and F operations
##################################################

#Written by Yann-Aël Le Borgne
#October 2007



##################################################
#Function getDist: returns the Euclidean norm bewteen pos1 and pos2
getDist<-function(pos1,pos2) {
 sqrt(sum((pos1-pos2)^2))
}


##################################################
#Function createTree: returns a tree from a set of positions
createTree<-function(
#Starting from the root node, sensors are assigned to their parent in the routing tree using a shortest path metric, until all sensors are connected. 
   pos,                   #A matrix of position of size p*2 where p is the number of sensors
   radius,                #The communication radius, determining the neighborhood of nodes
   root.id                #The id of the root node 
   ) {

#A node is an object with the following fields
# node<-list(
#    id              #An id
#    pos             #A position
#    parent          #A parent id
#    children        #A list of children nodes
#    nhop            #Number of hops to the root node
#    nbPackDef       #Number of packets processed if running the default mode (this is twice the size of the subtree+1)
#    nbPackPCA       #Number of packets processed if running the aggregation mode (this is the number of children+1)
#    )

#Initializes fiels for the root node
 node<-list(id=root.id,pos=c(pos[root.id,]),parent=NULL,children=numeric(),nhop=0,nbPackDef=1,nbPackPCA=1)

#Initializes the tree with the root node. The tree will be represented as a list of list of nodes
 tree<-list(list(node),NULL)
 
#p: number of sensors 
 p<-nrow(pos)
#rem.p: number of remaining sensors (not yet connected) 
 rem.p<-1:p
 rem.p<-rem.p[-root.id]
 
#Current level of connections in the routing tree
 level.act<-1
 
#While there is still nodes to connect 
 while (length(rem.p)>0) {
  print(level.act)

  node.connected<-numeric()

  #For all nodes not yet connected
  for (j in rem.p) {
  
   #Compute distance to nodes in the previous level, as weel as the number of hops to the root node
   dist.to.k<-numeric()
   n.hop<-numeric()
   for (k in 1:length(tree[[level.act]])) {
    dist.to.k<-c(dist.to.k,getDist(pos[j,],tree[[level.act]][[k]]$pos))
    n.hop<-c(n.hop,tree[[level.act]][[k]]$nhop)
   }
   
   #range.k: Vector of boolean telling which nodes are in range of the current node
   range.k<-(dist.to.k<=radius)
   
   #If at least one node   
   if (sum(as.numeric(range.k))>0) {
   	
   	#Takes the one whose number of hops to the root node is the lowest
    best.k<-which((range.k & (n.hop==min(n.hop[range.k])))==T)
    closest.k<-best.k[which.min(dist.to.k[best.k])][1]
 
    #Fill the node fields
    node<-list(id=j,pos=c(pos[j,]),parent=closest.k,children=NULL,nhop=tree[[level.act]][[closest.k]]$nhop+1,nbPackDef=1,nbPackPCA=1)
    parent.rec<-closest.k
    
    #Update the tree
    tree[[level.act]][[parent.rec]]$nbPackPCA<-tree[[level.act]][[parent.rec]]$nbPackPCA+1
    for (s in level.act:1) {
     tree[[s]][[parent.rec]]$nbPackDef<-tree[[s]][[parent.rec]]$nbPackDef+2
     parent.rec<-tree[[s]][[parent.rec]]$parent
    }
    tree[[level.act+1]]<-c(tree[[level.act+1]],list(node))
    children.number<-length(tree[[level.act+1]])
    tree[[level.act]][[closest.k]]$children<-c(tree[[level.act]][[closest.k]]$children,children.number)
    node.connected<-c(node.connected,j)
   }
  }
  
  #Remove the newly connected nodes from the list of nodes to connect
  rem.p<-setdiff(rem.p,node.connected)

  #If other nodes to connect, add a level to the tree
  if (length(rem.p)>0) tree<-c(tree,list(NULL))
  level.act<-level.act+1
 }
 
 #Returns the tree
 tree
}



##################################################
#Function dispTree: Displays the tree 
dispTree<-function(
      tree,       #A tree, obtained from the function create Tree
      pos         #A matrix of position of size p*2 where p is the number of sensors
      ) {
      	
 #Plot the sensor nodes
 plot(pos[,1],pos[,2],xlab="Position (m)",ylab="Position (m)")

 #Plot the connections
 for (i in 1:(length(tree)-1)) {
  for (j in 1:(length(tree[[i]]))) {
   if (length(tree[[i]][[j]]$children)>0) {
    for (k in 1:length(tree[[i]][[j]]$children)) {
     pos.parent<-tree[[i]][[j]]$pos
     pos.child<-tree[[i+1]][[tree[[i]][[j]]$children[k]]]$pos
     lines(c(pos.parent[1],pos.child[1]),c(pos.parent[2],pos.child[2]))
    }
   }
  }
 }

}

##################################################
#Function getHistTree: Helper function, returns the distribution of Packets received 
getHistTree<-function(
      pos,        #A matrix of position of size p*2 where p is the number of sensors
      n,          #Number of nodes
      radius      #A vector of communication radii, determining the neighborhood of nodes
      ) {
      	
      	
 size.r<-length(radius)
 histDef<-array(0,c(n,size.r))
 histPCA1<-array(0,c(n,size.r))
 histF<-array(1,c(n,size.r))
 
 for (s in 1:size.r){
  tree<-createTree(pos,radius[s],14)
  for (i in 1:(length(tree))) {
   for (j in 1:(length(tree[[i]]))) {
    histDef[tree[[i]][[j]]$id,s]<-tree[[i]][[j]]$nbPackDef
    histPCA1[tree[[i]][[j]]$id,s]<-tree[[i]][[j]]$nbPackPCA
    if (length(tree[[i]][[j]]$children)==0) {histF[tree[[i]][[j]]$id,s]<-0} 
   }
  }
 }
 list(histDef,histPCA1,histF)
}


