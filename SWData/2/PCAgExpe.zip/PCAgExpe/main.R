#This file contains the functions related to the network simulation
source("aggTree.R")
#This file contains the functions related to the data processing of data
source("PCAg.R")


##################################################
#loadData<-function() {

 #This gets the distance matrix from mote locations
 pos<-tr(read.table("mote_locs.txt")[,2:3])
 #Removes sensors 5 and 15, too few measurements
 pos<-pos[c(-5,-15),]
 posmax.x<-max(pos[,1])
 posmax.y<-max(pos[,2])
 pos[,1]<-posmax.x-pos[,1]
 pos[,2]<-posmax.y-pos[,2]
 distMat<-getDistMatFromPos(pos)

 #Load data - 8 days
 data<-tr(read.table("subsfin.txt"))
#}

##################################################
drawTree<-function() {

 tree<-createTree(pos,10,14)
 #postscript(file="mapIntel.eps",width=7,height=7)
 dispTree(tree,pos)
 #dev.off()
}

##################################################
drawProfile<-function() {
 #postscript(file="figProfileIntel.eps",width=7,height=7)
 i<-seq(1,2880*5,by=10)
 plot(i/2880+1,data[i,19],xlab="Days",ylab="Temperature (∞C)",main="Temperature variations over five days \n Sensor 21 - 2880 measurements per day",type="l")
 abline(v=2)
 abline(v=3)
 abline(v=4)
 abline(v=5)
 #dev.off()
}

##################################################
corGraph<-function() {
 #postscript(file="figSensCorIntel.eps",width=8,height=5.5)
 paro<-par(mfrow=c(1,2))
 i<-seq(1,2880*5,by=10)
 
 plot(data[i,19],data[i,20],xlab="Temperature - Sensor 21",ylab="Temperature - Sensor 22",main="Correlation coefficient: 0.99",pch=20)
 plot(data[i,19],data[i,47],xlab="Temperature - Sensor 21",ylab="Temperature - Sensor 49",main="Correlation coefficient: 0.59",pch=20)
 par(paro)
 #dev.off()
}

##################################################
intelVarRet<-function() {
 res<-comp10CV(data,50,c(1:25), distMat)
# res<-comp10CV(data[(2880*3+1):(2880*8),],50,c(1:25), distMat)
 res<-(1-res)*100

 #postscript(file="IntelVarRet.eps",width=7,height=7)
 mean.opt<-apply(res[1,,],1,mean)
 sd.opt<-apply(res[1,,],1,sd)
 plot(mean.opt,type="l",lty=2,ylim=c(70,100),xlab="Number of PCs", ylab="Variance retained (%)",main="Variance retained wrt PCs")
# for (i in 1:25) {
#  lines(c(i,i),c(mean.opt[i]-2*sd.opt[i],mean.opt[i]+1.6*sd.opt[i]))
# }
 mean.CV<-apply(res[3,,],1,mean)
 sd.CV<-apply(res[3,,],1,sd)
 lines(mean.CV)
# for (i in 1:25) {
#  lines(c(i,i),c(mean.CV[i]-2*sd.CV[i],mean.CV[i]+1.6*sd.CV[i]))
# }
 legend(15,90,legend=c("Test","Cross validation"),lty=c(2,1))
 #dev.off()
}

##################################################

approx21<-function() {
 res<-compressionCropIntel(data[1:1440,],data[(1441):(2880*5),],50,c(1,5,10,15), distMat)
 #postscript(file="IntelApproxSensor49.eps",width=7,height=7)
 
 plot((1:(2880*5))/2880+1,data[(1):(2880*5),47],type="l",ylim=c(15,37),xlab="Days",ylab="Temperature (∞C)",main="Approximations to sensor n∞49")
 lines((1441:(2880*5))/2880+1,res[[6]][1,],lty=2,col=2)
 lines((1441:(2880*5))/2880+1,res[[6]][2,],lty=3,col=4)
 lines((1441:(2880*5))/2880+1,res[[6]][4,],lty=4,col=6)
 abline(v=2)
 abline(v=3)
 abline(v=4)
 abline(v=5)
 legend(4,37,legend=c("Default","1 PC","5 PCs","15 PCs"),lty=c(1,2,3,4),col=c(1,2,4,6),bg=5)
 #dev.off()

}

##################################################
IntelCommCost1<-function() {

 #postscript(file="IntelCommCost2.eps",width=7,height=5)
 #paro<-par(mfrow=c(1,2))
 hist<-getHistTree(pos,52,c(6,10,20,30,40,50))
 df.nbPack<-data.frame(hist[[1]][,1:6])
 colnames(df.nbPack)<-c("6","10","20","30","40","50")
 boxplot(df.nbPack,las=3,ylim=c(0,120),ylab="Number of packets processed per cycle (Tx+Rx)",xlab="Communication radius (m)",main="Default data collection")

 df.nbPack<-data.frame(hist[[2]][,1:6])
 colnames(df.nbPack)<-c("6","10","20","30","40","50")
 boxplot(df.nbPack,las=3,ylim=c(0,120),ylab="Number of packets processed per cycle (Tx+Rx)",xlab="Communication radius (m)",main="Aggregation on one PC")
 #par(paro)
 #dev.off()
}


##################################################
IntelCommCost2<-function() {
 #postscript(file="IntelCommCost1.eps",width=7,height=7)
 hist<-getHistTree(pos,52,c(6,10,20,30,40,50))
 df.nbPack<-array(NA,c(52,4))
 df.nbPack[,1]<-hist[[1]][,2]
 df.nbPack[,2]<-hist[[2]][,2]
 df.nbPack[,3]<-hist[[2]][,2]*5
 df.nbPack[,4]<-hist[[2]][,2]*15
 df.nbPack<-data.frame(df.nbPack)
 colnames(df.nbPack)<-c("Default","1 PC","5 PCs","15 PCs")
 boxplot(df.nbPack,las=3,ylab="Number of packets processed per cycle",main="Network load incurred by default and PCA schemes")


 #dev.off()
}





##################################################
varRetCrop<-function() {
 res<-comp10CV(data[(1):(2880*5),],c(6,10,20,30,40,50),c(1:25), distMat) 
 res<-(1-res)*100

 #postscript(file="IntelVarRetCrop.eps",width=7,height=7)
 meancrop<-apply(res[8,,],1,mean)
 sdcrop<-apply(res[8,,],1,sd)
 plot(meancrop,type="l",lty=1,ylim=c(0,100),xlab="Number of PCs", ylab="Variance retained (%)",main="Variance retained wrt PCs \n for different covariance approximations")
 #for (i in 1:25) {
 # lines(c(i,i),c(meancrop[i]-sdcrop[i],meancrop[i]+sdcrop[i]))
 #}

 keep<-c(5,4,3,2)
 for (i in 1:4) {
  meancrop<-apply(res[keep[i],,],1,mean)
  sdcrop<-apply(res[keep[i],,],1,sd)
  lines(meancrop,lty=i+1)
  #for (i in 1:25) {
  # lines(c(i,i),c(meancrop[i]-sdcrop[i],meancrop[i]+sdcrop[i]))
  #}
 }
 legend(17,83,legend=c("All","20 meters","10 meters","6 meters","Random"),lty=c(1,2,3,4,5),title="Covariance values")

 #dev.off()
}


##################################################
matCovNetCost<-function() {
 crop<-c(6,10,20,30,40,50)
 sizecrop<-length(crop)
 q<-1:25
 sizeq<-length(q)
 p<-52

 nbNeigh<-array(0,c(p,sizecrop))
 nbPack<-array(0,c(sizecrop,sizeq))

 accuracyTest<-array(0,c(sizecrop,sizeq))
 accuracyTrain<-array(0,c(sizecrop,sizeq))
 accuracyRandom<-array(0,c(sizecrop,sizeq))

 for (i in 1:sizecrop) {
  distMatCrop<-cropMat(distMat,crop[i],distMat)
  nbNeigh[,i]<-apply(distMatCrop,2,getNbNeigh)
 }
 dfneigh<-data.frame(nbNeigh)
 colnames(dfneigh)<-c("6","10","20","30","40","50")
 #postscript(file="IntelCovMatNetCost.eps",width=7,height=7)
 boxplot(dfneigh,las=3,ylim=c(0,52),ylab="Number of packets processed per cycle (Tx+Rx)",xlab="Communication radius (m)",main="Network load incurred by covariances computation")
 #dev.off()   
}

##################################################




