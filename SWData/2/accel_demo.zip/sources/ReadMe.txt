To run the 'plateau3D' demo you will need :

2 MoteIV Tmote Invent Wireless Sensors.
1 computer with Tinyos Installed (MoteIV boomerang version)
A running version of Java
A installed copy of Java3D.


- First install the TOSBase program from moteIV on the Base node.
	Put One of the 2 motes on a USB port of your computer.
	Open the cigwyn shell
	cd /opt/moteiv/apps/TOSBase/
	make tmoteinvent
	make tmoteinvent install,0

- Secondly install the Acceloscope program on the moving node.
	copy the content of the directory sources/nesC/moving_node/opt in the /opt directory of you boomerang install.
	cd opt/tinyos-1.x/apps/Acceloscope
	make tmoteinvent
	make tmoteinvent install,1
	

- Now you put the mote 0 (with TOSBase) on a usb port of your computer.
  and you take mote 1 (with Acceloscope) on your desk (with the moteIV mark upside-right and the usb connector on the left)



- Finally copy the content of /sources/java/plateau/Plateau/build/classes somewhere (let's say in /opt/temp)
  Or you can recompile the sources in /sources/java/plateau/Plateau/src/plateau for your architecture and copy the .class files in /opt/temp
	cd /opt/temp/
	MOTECOM=serial@COM25:tmote java plateau.Plateau
	(where serial@COM25:tmote should be adapted to your configuration)


- Now you can play with mote 1 and see how it moves the 'plateau' and how the ball moves on it.


And here is a comment I receive from someone trying to run the plateau demo :
-----------------------------------------------------------------------------

Hi,
sorry to bother you again.
We are trying to run your program (platau) but it seems that there's a class missing (the one in the subject AccelMsg) we searched on internet for it but there's nothing about. Is it a specifi class you developed? Can you please tell us were we could find or what are the specs for this class? 

And my answer :
---------------

Oh sorry I forgot to mention this :

You have to generate it automaticaly using mig (Message Interface generator) for the file acceloscope.h

You can generate it adding this line to some tinyos Makefile :

    MIG = mig java $(MIGFLAGS)

    MSGS = AccelMsg.java

    INITIAL_TARGETS = $(MSGS)

    AccelMsg.java:
        $(MIG) -java-classname=$(PACKAGE).AccelMsg /opt/tinyos-1.x/apps/Acceloscope/Acceloscope.h AccelMsg -o $@



Take a look at the Makefile in cygwin\opt\tinyos-1.x\tools\java\net\tinyos\tools

I attach the makefile to this mail as well as the Java file for AccelMsg


----

So I added the file AccelMsg.java and the Makefile in the package.



