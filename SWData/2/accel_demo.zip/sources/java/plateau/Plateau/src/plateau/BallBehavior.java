/*
 * BallBehavior.java
 *
 * Created on 25 mars 2007, 21:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;


import java.util.Enumeration;
import javax.media.j3d.Behavior;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.WakeupOnElapsedTime;
import javax.vecmath.Vector3f;

/**
 *
 * @author dwarfy
 */
public class BallBehavior extends Behavior {
    private TransformGroup targetTG;
    private Plateau plat;
    Transform3D transBase = new Transform3D();
    Transform3D transRotX = new Transform3D();
    Transform3D transRotY = new Transform3D();
    float xt,xtt,yt,ytt,vxt,vxtt,vyt,vytt,dt,m,g,mod,maxx,maxy,dx,dy;
    
    
    /** Creates a new instance of BallBehavior */
    public BallBehavior(TransformGroup targetTG,Plateau p) {
        this.targetTG = targetTG;
        plat=p;
    }
    
    public void initialize() {
        System.out.println("init ball behav");
        xt=0;
        yt=0;
        vxt=0;
        vyt=0;
        g=9.81f;
        m=10f;
        dt=0.03333f;
        mod=0.5f;
        
        this.wakeupOn(new WakeupOnElapsedTime(Config.WAKEUP_TIME)); 
    }
    
    public void processStimulus(Enumeration criteria) {
        
        System.out.println("process ball");
        System.out.println(xt);
        System.out.println(yt);
        System.out.println(vxt);
        System.out.println(vyt);
        System.out.println(vyt);
        System.out.println((float)Math.sin(Math.PI/2 * (1-plat.xInc)));
        System.out.println((float)Math.sin(Math.PI/2 * (1-plat.yInc)));
        
        
        xtt = xt + vxt * dt;
        ytt = yt + vyt * dt;
        
        maxx=6f-(Config.SPHERE_RADIUS*10);
        maxy=6f-(Config.SPHERE_RADIUS*10);
        
        if (xtt>maxx) {
            xtt=maxx;
            vxt=-vxt*Config.REBOUND;
        } else if (xtt<-maxx) {
            xtt=-maxx;
            vxt=-vxt*Config.REBOUND;
        }
        
        if (ytt>maxy) {
            ytt=maxy;
            vyt=-vyt*Config.REBOUND;
        }else if (ytt<-maxy) {
            ytt=-maxy;
            vyt=-vyt*Config.REBOUND;
        }
        
        dx = xtt-xt;
        dy = ytt-yt;
        
        xt=xtt;
        yt=ytt;
        
        vxtt = vxt + (m * g * (float)Math.sin(Math.PI/2 * (1-plat.yInc)) * dt);
        vytt = vyt + (m * g * (float)Math.sin(Math.PI/2 * (1-plat.xInc)) * dt);
        
        vxt=vxtt;
        vyt=vytt;
        

        transRotX.rotX(-vxtt);
        transRotY.rotY(vytt);
        transRotX.mul(transRotY);
        
        
        transBase.setTranslation(new Vector3f(-0.1f,xtt/10,ytt/10));
        targetTG.setTransform(transBase);
        
        ((TransformGroup)targetTG.getChild(0)).setTransform(transRotX);
        
        
        
        
        this.wakeupOn(new WakeupOnElapsedTime(Config.WAKEUP_TIME)); 
    }
    
}
