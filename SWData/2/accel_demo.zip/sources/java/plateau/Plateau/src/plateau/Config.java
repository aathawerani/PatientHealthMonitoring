/*
 * Config.java
 *
 * Created on 21 mars 2007, 23:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;

/**
 *
 * @author dwarfy
 */
public class Config {
    public static int SLEEP_TIME = 100; //msec
      public static int DEF_POST_ID = 1;
      public static int GROUP_ID = 1;
      public static float SPHERE_RADIUS=0.05f;
      public static int SPHERE_DIV=50;
      public static long WAKEUP_TIME=(long)1024/30;
      public static float REBOUND = 0.4f;
    /** Creates a new instance of Config */
    public Config() {
    }
    
}
