package plateau;

import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Primitive;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.image.TextureLoader;
import java.awt.*;
import java.awt.event.*;
import com.sun.j3d.utils.universe.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class Plateau extends Panel implements ActionListener, KeyListener {

private Button go = new Button("Go");

private TransformGroup objRot; 
private TransformGroup objTrans;
private TransformGroup objRoll;
private TransformGroup objRotBordersN,objRotBordersS,objRotBordersW,objRotBordersE;

SimpleBehavior myRotationBehavior;
BallBehavior myBallBehavior;

private float height=0.0f;

private float xloc=0.0f;

public float xInc=0;
public float yInc=0;



public BranchGroup createSceneGraph() {

   // Create the root of the branch graph

   BranchGroup objRoot = new BranchGroup();

  
   
   
   objRot = new TransformGroup();
   objRot.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
   objRoot.addChild(objRot);
   
      
    Appearance app1 = new Appearance();
    //Create the colours for the material
    Color3f ambientColour = new Color3f(1.0f, 0.0f, 0.0f);
    Color3f diffuseColour = new Color3f(1.0f, 0.0f, 0.0f);
    Color3f specularColour = new Color3f(1.0f, 1.0f, 1.0f);
    Color3f emissiveColour = new Color3f(0.0f, 0.0f, 0.0f);
    //Define the shininess
    //Set the material of the appearance
    app1.setMaterial(new Material(ambientColour, emissiveColour,
        diffuseColour, specularColour, 50.0f));
      
        TextureAttributes texAttr = new TextureAttributes();
        //texAttr.setTextureMode(TextureAttributes.DECAL);
        TextureLoader loader = new TextureLoader("./plateau/wood.jpg",this);
        
        // Create Texture object
        Texture brick = loader.getTexture();

        // Create Appearance Object
        Appearance appear = new Appearance();
        appear.setTextureAttributes(texAttr);

        // Attach Texture object to Appearance object
        appear.setTexture(brick); 
        appear.setMaterial(new Material(ambientColour, emissiveColour,
        diffuseColour, specularColour, 128.0f));
        
      
      Box box1 = new Box(0.05f,0.6f,0.6f,Primitive.GENERATE_NORMALS + Primitive.GENERATE_TEXTURE_COORDS,appear);
      objRot.addChild(box1);
      
     
      
      Transform3D tmpN,tmpS,tmpW,tmpE;
      tmpN = new Transform3D();
      objRotBordersN = new TransformGroup();
      objRot.addChild(objRotBordersN);
      Box borderN= new Box(0.1f,0.05f,0.7f,Primitive.GENERATE_NORMALS + Primitive.GENERATE_TEXTURE_COORDS,appear);
      tmpN.setTranslation(new Vector3f(-0.0f,0.65f,0.0f));
      objRotBordersN.setTransform(tmpN);

      tmpS = new Transform3D();
      objRotBordersS = new TransformGroup();
      objRot.addChild(objRotBordersS);
      Box borderS= new Box(0.1f,0.05f,0.7f,Primitive.GENERATE_NORMALS + Primitive.GENERATE_TEXTURE_COORDS,appear);      
      tmpS.setTranslation(new Vector3f(-0.0f,-0.65f,0.0f));
      objRotBordersS.setTransform(tmpS);

      tmpW = new Transform3D();
      objRotBordersW = new TransformGroup();
      objRot.addChild(objRotBordersW);
      Box borderW= new Box(0.1f,0.6f,0.05f,Primitive.GENERATE_NORMALS + Primitive.GENERATE_TEXTURE_COORDS,appear);
      tmpW.setTranslation(new Vector3f(-0.0f,0.0f,0.65f));
      objRotBordersW.setTransform(tmpW);

      tmpE = new Transform3D();
      objRotBordersE = new TransformGroup();
      objRot.addChild(objRotBordersE);
      Box borderE= new Box(0.1f,0.6f,0.05f,Primitive.GENERATE_NORMALS + Primitive.GENERATE_TEXTURE_COORDS,appear);      
      tmpE.setTranslation(new Vector3f(-0.0f,0.0f,-0.65f));
      objRotBordersE.setTransform(tmpE);
      
      
      objRotBordersN.addChild(borderN);
      objRotBordersS.addChild(borderS);
      objRotBordersW.addChild(borderW);
      objRotBordersE.addChild(borderE);
        
      
      objTrans = new TransformGroup();
      objTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);      
      objRot.addChild(objTrans);
      
      objRoll = new TransformGroup();
      objRoll.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);     
      objTrans.addChild(objRoll);
      
      
      
      Sphere sph = new Sphere(Config.SPHERE_RADIUS,Sphere.GENERATE_NORMALS,Config.SPHERE_DIV,app1);
      objRoll.addChild(sph);


      
      
   
   //objRot.addChild(new ColorCube(0.4f));
   
   
   myRotationBehavior = new SimpleBehavior(objRot,this);  
   myBallBehavior = new BallBehavior(objTrans,this);
   

   BoundingSphere bounds =
      new BoundingSphere(new Point3d(0.0,0.0,0.0), 100.0);
   
   myRotationBehavior.setSchedulingBounds(bounds);
   myBallBehavior.setSchedulingBounds(bounds);
   
   objRoot.addChild(myRotationBehavior);
   objRoot.addChild(myBallBehavior);
      
   
   Color3f light1Color = new Color3f(1.0f,1.0f, 1.0f);
   Vector3f light1Direction = new Vector3f(-1.0f, -1.0f, -1.0f);

   DirectionalLight light1

      = new DirectionalLight(light1Color, light1Direction);

   light1.setInfluencingBounds(bounds);
   light1.setEnable(true);

   objRoot.addChild(light1);

   // Set up the ambient light

   Color3f ambientColor = new Color3f(1.0f, 1.0f, 1.0f);

   AmbientLight ambientLightNode = new AmbientLight(ambientColor);

   ambientLightNode.setInfluencingBounds(bounds);

   objRoot.addChild(ambientLightNode);
   
   objRoot.compile();

   return objRoot;

}

public Plateau() {

   setLayout(new BorderLayout());

   GraphicsConfiguration config =

      SimpleUniverse.getPreferredConfiguration();

   Canvas3D c = new Canvas3D(config);

   add("Center", c);

   c.addKeyListener(this);

   //timer = new Timer(100,this);

   //timer.start();

   Panel p =new Panel();

   p.add(go);

   add("North",p);

   go.addActionListener(this);

   go.addKeyListener(this);

   // Create a simple scene and attach it to the virtual universe

   BranchGroup scene = createSceneGraph();

   SimpleUniverse u = new SimpleUniverse(c);

   u.getViewingPlatform().setNominalViewingTransform();

   u.addBranchGraph(scene);

}

public void keyPressed(KeyEvent e) {

   //Invoked when a key has been pressed.

   if (e.getKeyChar()=='s') {xloc = xloc + .1f;}

   if (e.getKeyChar()=='a') {xloc = xloc - .1f;}

}

public void keyReleased(KeyEvent e){

   // Invoked when a key has been released.

}

public void keyTyped(KeyEvent e){

   //Invoked when a key has been typed.

}

public void actionPerformed(ActionEvent e ) {

  /* // start timer when button is pressed

   if (e.getSource()==go){

        RefreshThread RT = new RefreshThread()

   } else {
       
   
  //trans.setRotation(0.2,0.3,0.0);
   Transform3D rot = new Transform3D();
   rot.rotX(Math.PI);
   trans.mul(rot);
           
   trans.setTranslation(new Vector3f(xloc,height,0.0f));
   trans.setScale(new Vector3d(.5,.1,.5));
   objTrans.setTransform(trans);
       
   }

   */

}

public void refresh(int accelX,int accelY) {
        //here we have the latest accel data
        
        float aaX,aaY;
        aaX=accelX-8;
        aaY=accelY-22;
    
        //smooth it    
        if (aaX < 1800) {aaX=1800;}
        else if (aaX > 2200) {aaX=2200;}
        
        if (aaY < 1800) {aaY=1800;}
        else if (aaY > 2200) {aaY=2200;}
        
        aaX-=2000;
        aaY-=2000;
        
        aaX/=200;
        aaY/=200;


        int a = (int)((1-aaX)*100);
        int b = (int)((1-aaY)*100);
        
        xInc = (float) a / 100;
        yInc = (float) b / 100;
        
        
        System.out.println("AccelX:"+xInc);
        System.out.println("AccelY:"+yInc);

        myRotationBehavior.postId(Config.DEF_POST_ID);

        
        /*
        Transform3D rot1 = new Transform3D();
        Transform3D rot2 = new Transform3D();

        rot1.rotX(Math.PI * accelX); //angle radians 2PI r = 360 �
        rot2.rotY(Math.PI * accelY);
        rot1.mul(rot2);
        
        //update view
        objRot.setTransform(rot1);   
        
        System.out.println(String.valueOf(Math.PI * accelX));
        System.out.println(String.valueOf(Math.PI * accelY));*/
    
}

public static void main(String[] args) {

   System.out.println("Program Started");

   Plateau bb = new Plateau();

   bb.addKeyListener(bb);
   
   SerialReceiver S=new SerialReceiver();
   S.setPlateau(bb);
   
   Frame mf = new Frame();   
   //mf.set
   mf.add(bb);
   
   mf.pack();
   mf.setVisible(true);
   

   
   

}



}