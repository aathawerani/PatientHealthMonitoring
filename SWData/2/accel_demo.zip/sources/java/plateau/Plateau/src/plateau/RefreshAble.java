/*
 * RefreshAble.java
 *
 * Created on 21 mars 2007, 23:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;

/**
 *
 * @author dwarfy
 */
public interface RefreshAble {
 void refresh();    
}
