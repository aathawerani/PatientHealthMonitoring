/*
 * RefreshThread.java
 *
 * Created on 21 mars 2007, 23:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;

/**
 *
 * @author dwarfy
 */

import java.io.IOException;


public class RefreshThread extends Thread {
    RefreshAble Robj;
    long minPrime;
    public RefreshThread(int mp) {
        minPrime=mp;
    }



    public void setRefreshObj(RefreshAble o){
        Robj = o;
    }
    
        public void run() {


         while (true) {
            try {
               Thread.sleep(Config.SLEEP_TIME);;
            } catch (Exception e) {
                System.out.println("RefreshThread: can't sleep");
            }
            
            Robj.refresh();
         }
         
    }



}