/*
 * SerialReceiver.java
 *
 * Created on 21 mars 2007, 18:19
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;

/**
 *
 * @author dwarfy
 */
/*
 * SerialReceiver.java
 *
 * Created on 8 mars 2007, 16:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import net.tinyos.tools.AccelMsg;

import net.tinyos.util.*;
import net.tinyos.message.*;

import java.util.LinkedList;
import java.util.ListIterator;

import java.awt.*;


/**
 *
 * @author dwarfy
 * This components listen on serial
 * When a NodeInfoMsg arrives it puts it at the start of the nodeInfoList
 * When a CalibrationMsg arrives it puts it at the start of the nodeInfoList
 */
public class SerialReceiver implements MessageListener {
    private MoteIF mote;
    private Plateau plat;


    public void messageReceived(int dest_addr, Message msg) {
    if (msg instanceof AccelMsg) {
      accReceived( dest_addr, (AccelMsg)msg);      
    } else {
      //throw new RuntimeException("messageReceived: Got bad message type: "+msg);
    }
  }


    /**
     * Creates a new instance of SerialReceiver
     */
    public MoteIF getMote() {
        return mote;
    }

    public SerialReceiver() {
        // OK, connect to the serial forwarder and start receiving data
                System.out.println("SerialReceiver:Start");
		mote = new MoteIF(PrintStreamMessenger.err, Config.GROUP_ID);
		mote.registerListener(new AccelMsg(), this);
    }
    
    public void setPlateau(Plateau p) {
        plat=p;
    }

     public void accReceived(int dest,AccelMsg msg) {
        System.out.println("accelX = ".concat(String.valueOf(msg.get_accelX())).concat(" | accelY = ").concat(String.valueOf(msg.get_accelY())));
        plat.refresh(msg.get_accelX(),msg.get_accelY());
         
    }
}
