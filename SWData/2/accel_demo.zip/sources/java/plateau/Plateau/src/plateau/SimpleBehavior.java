/*
 * SimpleBehavior.java
 *
 * Created on 22 mars 2007, 1:54
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plateau;

import java.util.Enumeration;
import javax.media.j3d.Behavior;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnBehaviorPost;

/**
 *
 * @author dwarfy
 */
public class SimpleBehavior extends Behavior {
  private TransformGroup targetTG;
  private Plateau plat;
  Transform3D rot1 = new Transform3D();
  Transform3D rot2 = new Transform3D();


  public SimpleBehavior(TransformGroup targetTG,Plateau p) {
    System.out.println("create Behavior");
    this.targetTG = targetTG;
    plat=p;
  }

  /**
   * initialize the Behavior
   * 
   * set initial wakeup condition called when behavior 
   * beacomes live
   */ 
  public void initialize() {
    // set initial wakeup condition
     System.out.println("init mote behav");
     this.wakeupOn(new WakeupOnBehaviorPost(this,Config.DEF_POST_ID));
  }

  /**
   * behave
   * 
   * called by Java 3D when appropriate stimulus occures
   */
  public void processStimulus(Enumeration criteria) {
    // decode event
    // do what is necessary

        System.out.println("process mote");
        rot1.rotX((5*Math.PI/8) + Math.PI/2 * plat.xInc); //angle radians 2PI r = 360 �
        rot2.rotZ(Math.PI/2 * plat.yInc);
        rot1.mul(rot2);
        
        //update view
        targetTG.setTransform(rot1);         
        this.wakeupOn(new WakeupOnBehaviorPost(this,Config.DEF_POST_ID));
  }
}