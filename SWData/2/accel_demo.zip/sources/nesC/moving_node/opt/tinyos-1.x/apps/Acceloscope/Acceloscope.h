//Acceloscope.h
//a simple program that sends peridodically the accel value of the tmote invent over radio

#ifndef H_Acceloscope_h
#define H_Acceloscope_h


enum {
	INTER_MESSAGE_TIME = 102,
	BASE_ADRESS = 0
};

enum {
	AM_ACCELMSG = 33,
};


typedef struct AccelMsg {
	uint8_t nodeId;
	uint32_t seqNo; 							//the Corresponding ReadingsMsg seq_no
	uint16_t accelX;
	uint16_t accelY;
} AccelMsg;

#endif //H_Acceloscope_h

